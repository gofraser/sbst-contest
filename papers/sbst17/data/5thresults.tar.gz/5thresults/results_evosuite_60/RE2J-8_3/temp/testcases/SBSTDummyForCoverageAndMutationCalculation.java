import org.junit.Test;

public class SBSTDummyForCoverageAndMutationCalculation{

@org.junit.Test
public void test(){}
}
